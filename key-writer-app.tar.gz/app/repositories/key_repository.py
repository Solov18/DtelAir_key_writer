import math
import re
from sqlalchemy.exc import IntegrityError

from app.db import db
from app.search_utils import (
    assignment_address_sql,
    normalize_search_text,
    parse_assignment_search_query,
)
from app.key_numbers import (
    exact_key_number_sql,
    format_numeric_key_number,
    infer_numeric_key_number_width,
    is_numeric_key_number,
    key_number_search_sql,
)


KEY_STATUSES = {
    "free": "Свободен",
    "issued_resident": "Выдан жильцу",
    "issued_employee": "Выдан сотруднику",
    "issued_contractor": "Выдан подрядчику",
    "issued_other": "Выдан",
    "assigned_uk": "Закреплён за УК",
    "blocked": "Заблокирован",
    "lost": "Утерян",
    "defective": "Брак",
    "archived": "Архив",
}

KEY_STATUS_TONES = {
    "free": "success",
    "issued_resident": "info",
    "issued_employee": "purple",
    "issued_contractor": "purple",
    "issued_other": "info",
    "assigned_uk": "warning",
    "blocked": "danger",
    "lost": "danger",
    "defective": "warning",
    "archived": "muted",
}

ASSIGNMENT_STATUSES = {
    "resident": "issued_resident",
    "employee": "issued_employee",
    "uk": "assigned_uk",
    "contractor": "issued_contractor",
    "other": "issued_other",
}

ASSIGNMENT_TYPE_NAMES = {
    "resident": "Жилец",
    "uk": "УК",
    "employee": "Сотрудник",
    "contractor": "Подрядчик",
    "other": "Другой",
}


def key_status_name(status: str) -> str:
    return KEY_STATUSES.get(status, status or "—")


def key_status_tone(status: str) -> str:
    return KEY_STATUS_TONES.get(status, "muted")


def _normalize_hex(value: str) -> str:
    value = (value or "").strip().upper()
    return value.replace(" ", "").replace(":", "").replace("-", "")


def _assignment_text(row: dict) -> str:
    assignment_type = row.get("assignment_type") or ""
    # ``note`` belongs to the physical key itself; only the active assignment
    # note may describe its current owner.
    owner_name = (row.get("assignment_note") or "").strip()

    if assignment_type == "resident":
        parts = [row.get("assignment_address") or "Жилец"]
        if row.get("assignment_apartment"):
            parts.append(f"кв. {row['assignment_apartment']}")
        return " / ".join(parts)

    if assignment_type == "employee":
        return owner_name or row.get("employee_name") or "Сотрудник"

    if assignment_type == "uk":
        return owner_name or row.get("uk_name") or "Управляющая компания"

    if assignment_type in {"contractor", "other"}:
        return owner_name or ASSIGNMENT_TYPE_NAMES[assignment_type]

    return "Свободен"


def _normalize_key_row(row) -> dict:
    item = dict(row)
    item["status_name"] = key_status_name(item.get("status", ""))
    item["status_tone"] = key_status_tone(item.get("status", ""))
    item["assignment_text"] = _assignment_text(item)
    item["assignment_type_name"] = ASSIGNMENT_TYPE_NAMES.get(
        item.get("assignment_type") or "",
        "",
    )
    item["has_hex"] = bool(item.get("hex_value"))
    return item


def _key_count_text(value: int) -> str:
    count = int(value or 0)
    if count % 10 == 1 and count % 100 != 11:
        word = "ключ"
    elif count % 10 in {2, 3, 4} and count % 100 not in {12, 13, 14}:
        word = "ключа"
    else:
        word = "ключей"
    return f"{count} {word}"


def get_key_types(include_archived: bool = True) -> list[dict]:
    where = "" if include_archived else "WHERE kt.enabled = 1"

    with db() as conn:
        rows = conn.execute(
            f"""
            SELECT
                kt.*,
                COUNT(k.id) AS keys_count,
                SUM(CASE WHEN k.status = 'free' THEN 1 ELSE 0 END) AS free_count,
                (
                    SELECT k2.number
                    FROM keys k2
                    WHERE k2.key_type_id = kt.id
                      AND TRIM(k2.hex_value) <> ''
                      AND k2.number <> ''
                      AND k2.number ~ '^[0-9]+$'
                    ORDER BY CAST(k2.number AS NUMERIC) DESC,
                             LENGTH(k2.number) DESC,
                             k2.id DESC
                    LIMIT 1
                ) AS last_number
            FROM key_types kt
            LEFT JOIN keys k
                   ON k.key_type_id = kt.id
                  AND TRIM(k.hex_value) <> ''
            {where}
            GROUP BY kt.id
            ORDER BY kt.enabled DESC, LOWER(kt.name), kt.name
            """
        ).fetchall()
        items = [dict(row) for row in rows]

    for item in items:
        last_number = (item.get("last_number") or "").strip()
        item["last_number"] = last_number
        item["keys_count_text"] = _key_count_text(item.get("keys_count", 0))
        item["next_number"] = (
            str(int(last_number) + 1).zfill(len(last_number))
            if last_number.isdigit()
            else ""
        )

    return items


def get_key_type(key_type_id: int) -> dict | None:
    with db() as conn:
        row = conn.execute(
            "SELECT * FROM key_types WHERE id = ?",
            (key_type_id,),
        ).fetchone()
        return dict(row) if row else None


def search_keys_for_selection(
    query: str,
    *,
    key_type_id: int | None = None,
    only_free: bool = False,
    limit: int = 12,
) -> list[dict]:
    """Search the full key registry for picker/autocomplete components.

    Numbers remain strings so leading zeroes are never discarded.  Availability
    is calculated by the database and consumers may display occupied matches
    without allowing them to be selected.
    """

    from app.services.key_search import KeySearchProfile, KeySearchService

    return [
        item.as_legacy_dict()
        for item in KeySearchService.search(
            query,
            profile=KeySearchProfile.PICKER,
            type_id=key_type_id,
            available_only=only_free,
            limit=min(int(limit), 50),
        )
    ]


def get_missing_key_numbers(
    key_type_id: int,
    start_number: str = "",
    end_number: str = "",
    limit: int = 500,
) -> dict:
    """Return missing numeric key numbers without expanding huge ranges in memory."""
    key_type = get_key_type(key_type_id)
    if not key_type:
        raise ValueError("Тип ключа не найден.")

    clean_start = (start_number or "").strip()
    clean_end = (end_number or "").strip()
    if clean_start and not re.fullmatch(r"[0-9]+", clean_start):
        raise ValueError("Начало диапазона должно состоять только из цифр.")
    if clean_end and not re.fullmatch(r"[0-9]+", clean_end):
        raise ValueError("Конец диапазона должен состоять только из цифр.")

    with db() as conn:
        rows = conn.execute(
            """
            SELECT number
            FROM keys
            WHERE key_type_id = ?
              AND TRIM(hex_value) <> ''
              AND number <> ''
              AND number ~ '^[0-9]+$'
            ORDER BY CAST(number AS NUMERIC), LENGTH(number), number
            """,
            (key_type_id,),
        ).fetchall()

    stored_values = [str(row["number"]).strip() for row in rows]
    stored_numbers = sorted({int(value) for value in stored_values})
    if not stored_numbers and not (clean_start and clean_end):
        return {
            "key_type": key_type,
            "start": "",
            "end": "",
            "ranges": [],
            "numbers": [],
            "missing_count": 0,
            "shown_count": 0,
            "truncated": False,
            "empty_type": True,
        }

    start_value = int(clean_start) if clean_start else stored_numbers[0]
    end_value = int(clean_end) if clean_end else stored_numbers[-1]
    if end_value < start_value:
        raise ValueError("Конец диапазона не может быть меньше начала.")
    if end_value - start_value > 10_000_000:
        raise ValueError("Диапазон слишком большой. Уточните начало и конец проверки.")

    display_width = infer_numeric_key_number_width(stored_values)
    present = [
        number
        for number in stored_numbers
        if start_value <= number <= end_value
    ]

    ranges: list[dict] = []
    numbers: list[str] = []
    missing_count = 0
    cursor = start_value

    def add_gap(gap_start: int, gap_end: int) -> None:
        nonlocal missing_count
        if gap_end < gap_start:
            return
        count = gap_end - gap_start + 1
        missing_count += count
        ranges.append(
            {
                "start": format_numeric_key_number(gap_start, display_width),
                "end": format_numeric_key_number(gap_end, display_width),
                "count": count,
            }
        )
        remaining = max(0, limit - len(numbers))
        if remaining:
            numbers.extend(
                format_numeric_key_number(value, display_width)
                for value in range(
                    gap_start,
                    min(gap_end + 1, gap_start + remaining),
                )
            )

    for number in present:
        if number > cursor:
            add_gap(cursor, number - 1)
        cursor = max(cursor, number + 1)
    add_gap(cursor, end_value)

    return {
        "key_type": key_type,
        "start": format_numeric_key_number(start_value, display_width),
        "end": format_numeric_key_number(end_value, display_width),
        "ranges": ranges,
        "numbers": numbers,
        "missing_count": missing_count,
        "shown_count": len(numbers),
        "truncated": missing_count > len(numbers),
        "empty_type": False,
    }


def create_key_type(
    name: str,
    color: str,
    note: str = "",
) -> int:
    clean_name = (name or "").strip()
    clean_color = (color or "#2A9DF4").strip()

    if not clean_name:
        raise ValueError("Укажите название типа ключа.")

    if not re.fullmatch(r"#[0-9A-Fa-f]{6}", clean_color):
        raise ValueError("Цвет должен быть указан в формате #RRGGBB.")

    try:
        with db() as conn:
            cursor = conn.execute(
                """
                INSERT INTO key_types(name, color, note, enabled)
                VALUES (?, ?, ?, 1)
                """,
                (clean_name, clean_color.upper(), (note or "").strip()),
            )
            return int(cursor.lastrowid)
    except IntegrityError as error:
        raise ValueError("Тип ключа с таким названием уже существует.") from error


def update_key_type(
    key_type_id: int,
    name: str,
    color: str,
    note: str,
    enabled: bool,
) -> None:
    clean_name = (name or "").strip()
    clean_color = (color or "#2A9DF4").strip().upper()

    if not clean_name:
        raise ValueError("Укажите название типа ключа.")

    if not re.fullmatch(r"#[0-9A-F]{6}", clean_color):
        raise ValueError("Некорректный цвет типа ключа.")

    try:
        with db() as conn:
            cursor = conn.execute(
                """
                UPDATE key_types
                SET name = ?,
                    color = ?,
                    note = ?,
                    enabled = ?,
                    updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
                """,
                (
                    clean_name,
                    clean_color,
                    (note or "").strip(),
                    1 if enabled else 0,
                    key_type_id,
                ),
            )
            if cursor.rowcount == 0:
                raise ValueError("Тип ключа не найден.")

            conn.execute(
                """
                UPDATE keys
                SET key_type = ?, updated_at = CURRENT_TIMESTAMP
                WHERE key_type_id = ?
                """,
                (clean_name, key_type_id),
            )
    except IntegrityError as error:
        raise ValueError("Тип ключа с таким названием уже существует.") from error


def get_key_statistics() -> dict:
    with db() as conn:
        row = conn.execute(
            """
            SELECT
                COUNT(*) AS total,
                SUM(CASE WHEN status = 'free' THEN 1 ELSE 0 END) AS free,
                SUM(CASE WHEN status = 'issued_resident' THEN 1 ELSE 0 END) AS residents,
                SUM(CASE WHEN status = 'issued_employee' THEN 1 ELSE 0 END) AS employees,
                SUM(CASE WHEN status = 'assigned_uk' THEN 1 ELSE 0 END) AS uk,
                SUM(CASE WHEN status IN ('blocked', 'lost', 'defective') THEN 1 ELSE 0 END) AS blocked
            FROM keys
            WHERE TRIM(hex_value) <> ''
            """
        ).fetchone()
        return {key: int(value or 0) for key, value in dict(row).items()}


def _keys_filter_sql(
    query: str = "",
    key_type_id: int | None = None,
    status: str = "",
    availability: str = "",
    added_from: str = "",
    added_to: str = "",
    assigned_from: str = "",
    assigned_to: str = "",
) -> tuple[str, list]:
    conditions = ["TRIM(k.hex_value) <> ''"]
    params: list = []

    normalized_query = normalize_search_text(query)
    if normalized_query:
        parsed = parse_assignment_search_query(query)
        if parsed["has_apartment"]:
            conditions.append("ka.id IS NOT NULL")
            conditions.append("SMART_NORM(ka.apartment) = ?")
            params.append(normalize_search_text(parsed["apartment"]))
            if parsed["looks_like_address"]:
                address_sql, address_params = assignment_address_sql(parsed)
                conditions.append(f"({address_sql})")
                params.extend(address_params)
        elif parsed["looks_like_address"]:
            address_sql, address_params = assignment_address_sql(parsed)
            conditions.extend(("ka.id IS NOT NULL", f"({address_sql})"))
            params.extend(address_params)
        elif is_numeric_key_number(query):
            number_sql, number_params = exact_key_number_sql("k.number", query)
            compact_hex = re.sub(r"[^0-9A-Fa-f]", "", query).upper()
            conditions.append(
                f"""
                (
                    {number_sql}
                    OR REGEXP_REPLACE(
                        UPPER(COALESCE(k.hex_value, '')),
                        '[^0-9A-F]',
                        '',
                        'g'
                    ) = ?
                )
                """
            )
            params.extend([*number_params, compact_hex])
        else:
            pattern = f"%{normalized_query}%"
            number_sql, number_params = key_number_search_sql(
                "k.number", query, pattern=pattern
            )
            conditions.append(
                f"""
                (
                    {number_sql}
                    OR SMART_NORM(k.hex_value) LIKE ?
                    OR SMART_NORM(kt.name) LIKE ?
                    OR SMART_NORM(k.note) LIKE ?
                    OR SMART_NORM(ka.address) LIKE ?
                    OR SMART_NORM(ka.apartment) LIKE ?
                    OR SMART_NORM(e.full_name) LIKE ?
                    OR SMART_NORM(ug.name) LIKE ?
                    OR SMART_NORM(ka.note) LIKE ?
                    OR SMART_NORM(CONCAT(
                        CASE ka.assignment_type
                            WHEN 'resident' THEN 'Жилец'
                            WHEN 'employee' THEN 'Сотрудник'
                            WHEN 'uk' THEN 'УК управляющая компания'
                            WHEN 'contractor' THEN 'Подрядчик'
                            WHEN 'other' THEN 'Другой'
                            ELSE ''
                        END,
                        ' ', COALESCE(ka.note, ''),
                        ' ', COALESCE(e.full_name, ''),
                        ' ', COALESCE(ug.name, '')
                    )) LIKE ?
                    OR SMART_NORM(CASE k.status
                    WHEN 'free' THEN 'Свободен'
                    WHEN 'issued_resident' THEN 'Выдан жильцу'
                    WHEN 'issued_employee' THEN 'Выдан сотруднику'
                    WHEN 'issued_contractor' THEN 'Выдан подрядчику'
                    WHEN 'issued_other' THEN 'Выдан'
                    WHEN 'assigned_uk' THEN 'Закреплён за УК'
                    WHEN 'blocked' THEN 'Заблокирован'
                    WHEN 'lost' THEN 'Утерян'
                    WHEN 'defective' THEN 'Брак'
                    WHEN 'archived' THEN 'Архив'
                    END) LIKE ?
                )
                """
            )
            params.extend([*number_params, *([pattern] * 10)])

    if key_type_id:
        conditions.append("k.key_type_id = ?")
        params.append(key_type_id)

    if status in KEY_STATUSES:
        conditions.append("k.status = ?")
        params.append(status)

    if availability == "free":
        conditions.append("k.status = 'free'")
        conditions.append("ka.id IS NULL")
    elif availability == "used":
        conditions.append("k.status <> 'free'")

    if added_from:
        conditions.append("substr(k.created_at, 1, 10) >= ?")
        params.append(added_from)

    if added_to:
        conditions.append("substr(k.created_at, 1, 10) <= ?")
        params.append(added_to)

    if assigned_from:
        conditions.append("substr(ka.assigned_at, 1, 10) >= ?")
        params.append(assigned_from)

    if assigned_to:
        conditions.append("substr(ka.assigned_at, 1, 10) <= ?")
        params.append(assigned_to)

    return " AND ".join(conditions), params


def get_keys_page(
    *,
    query: str = "",
    key_type_id: int | None = None,
    status: str = "",
    availability: str = "",
    added_from: str = "",
    added_to: str = "",
    assigned_from: str = "",
    assigned_to: str = "",
    page: int = 1,
    page_size: int = 50,
) -> dict:
    page = max(1, int(page or 1))
    page_size = min(200, max(20, int(page_size or 50)))
    where_sql, params = _keys_filter_sql(
        query,
        key_type_id,
        status,
        availability,
        added_from,
        added_to,
        assigned_from,
        assigned_to,
    )

    joins = """
        JOIN key_types kt ON kt.id = k.key_type_id
        LEFT JOIN key_assignments ka ON ka.key_id = k.id AND ka.active = 1
        LEFT JOIN employees e ON e.id = ka.employee_id
        LEFT JOIN uk_groups ug ON ug.id = ka.uk_group_id
    """

    with db() as conn:
        total = int(
            conn.execute(
                f"SELECT COUNT(*) FROM keys k {joins} WHERE {where_sql}",
                params,
            ).fetchone()[0]
        )
        pages = max(1, math.ceil(total / page_size))
        page = min(page, pages)
        offset = (page - 1) * page_size
        rows = conn.execute(
            f"""
            SELECT
                k.*,
                kt.name AS type_name,
                kt.color AS type_color,
                kt.enabled AS type_enabled,
                ka.assignment_type,
                ka.address AS assignment_address,
                ka.apartment AS assignment_apartment,
                ka.assigned_at,
                ka.note AS assignment_note,
                e.full_name AS employee_name,
                e.position AS employee_position,
                ug.name AS uk_name
            FROM keys k
            {joins}
            WHERE {where_sql}
            ORDER BY k.id DESC
            LIMIT ? OFFSET ?
            """,
            [*params, page_size, offset],
        ).fetchall()

    return {
        "items": [_normalize_key_row(row) for row in rows],
        "total": total,
        "page": page,
        "pages": pages,
        "page_size": page_size,
    }


def get_recent_keys(limit: int = 300) -> list[dict]:
    return get_keys_page(page_size=min(limit, 200))["items"]


def get_key(key_id: int) -> dict | None:
    with db() as conn:
        row = conn.execute(
            """
            SELECT
                k.*,
                kt.name AS type_name,
                kt.color AS type_color,
                kt.enabled AS type_enabled,
                ka.id AS assignment_id,
                ka.assignment_type,
                ka.address AS assignment_address,
                ka.apartment AS assignment_apartment,
                ka.assigned_at,
                ka.assigned_by,
                ka.note AS assignment_note,
                e.full_name AS employee_name,
                e.position AS employee_position,
                ug.name AS uk_name
            FROM keys k
            JOIN key_types kt ON kt.id = k.key_type_id
            LEFT JOIN key_assignments ka ON ka.key_id = k.id AND ka.active = 1
            LEFT JOIN employees e ON e.id = ka.employee_id
            LEFT JOIN uk_groups ug ON ug.id = ka.uk_group_id
            WHERE k.id = ?
            """,
            (key_id,),
        ).fetchone()
        return _normalize_key_row(row) if row else None


def get_key_write_contexts(key_ids: list[int]) -> dict[int, dict]:
    """Return active assignments and known panel access for a group of keys.

    A panel is considered known only after a successful write (or an explicit
    ``already exists`` response).  The latest successful remove operation
    closes that relation.  This keeps preview and write validation on one
    server-side source without issuing requests to physical panels.
    """

    clean_ids = sorted({int(value) for value in key_ids if int(value) > 0})
    if not clean_ids:
        return {}
    placeholders = ", ".join("?" for _ in clean_ids)
    with db() as conn:
        assignment_rows = conn.execute(
            f"""
            SELECT
                k.id AS key_id,
                k.status AS key_status,
                k.number AS key_number,
                k.hex_value,
                kt.name AS key_type_name,
                ka.id AS assignment_id,
                ka.assignment_type,
                ka.address AS assignment_address,
                ka.apartment AS assignment_apartment,
                ka.note AS assignment_note,
                ka.assigned_at,
                e.full_name AS employee_name,
                ug.name AS uk_name
            FROM keys k
            JOIN key_types kt ON kt.id = k.key_type_id
            LEFT JOIN key_assignments ka
                ON ka.key_id = k.id AND ka.active = 1
            LEFT JOIN employees e ON e.id = ka.employee_id
            LEFT JOIN uk_groups ug ON ug.id = ka.uk_group_id
            WHERE k.id IN ({placeholders})
            ORDER BY k.id, ka.assigned_at DESC, ka.id DESC
            """,
            clean_ids,
        ).fetchall()
        panel_rows = conn.execute(
            f"""
            WITH latest_success AS (
                SELECT DISTINCT ON (ol.key_id, ol.panel_id)
                    ol.key_id,
                    ol.panel_id,
                    ol.action,
                    ol.mode,
                    ol.created_at,
                    ol.id
                FROM operation_log ol
                WHERE ol.key_id IN ({placeholders})
                  AND ol.panel_id IS NOT NULL
                  AND UPPER(COALESCE(ol.status, '')) IN ('SUCCESS', 'ALREADY_EXISTS')
                ORDER BY ol.key_id, ol.panel_id, ol.id DESC
            )
            SELECT
                ls.*,
                p.address,
                p.entrance,
                p.name,
                p.mac
            FROM latest_success ls
            JOIN panels p ON p.id = ls.panel_id
            ORDER BY p.address, p.entrance, p.name
            """,
            clean_ids,
        ).fetchall()

    contexts: dict[int, dict] = {}
    for row in assignment_rows:
        item = dict(row)
        assignment_type = item.get("assignment_type") or ""
        owner = (
            item.get("assignment_note")
            or item.get("employee_name")
            or item.get("uk_name")
            or ""
        )
        key_id = int(item["key_id"])
        assignment = {
            "id": item.get("assignment_id"),
            "assignment_type": assignment_type,
            "assignment_type_name": ASSIGNMENT_TYPE_NAMES.get(
                assignment_type,
                assignment_type or "—",
            ),
            "assignment_address": item.get("assignment_address") or "",
            "assignment_apartment": item.get("assignment_apartment") or "",
            "owner_name": owner,
            "assigned_at": item.get("assigned_at"),
        }
        context = contexts.get(key_id)
        if context is None:
            context = {
                **item,
                **assignment,
                "is_used": bool(
                    item.get("assignment_id")
                    or item.get("key_status") not in {"", "free"}
                ),
                "assignments": [],
                "panels": [],
                "panel_ids": [],
            }
            contexts[key_id] = context
        if assignment["id"]:
            context["assignments"].append(assignment)

    removal_markers = ("remove", "delete", "unlink")
    for row in panel_rows:
        item = dict(row)
        action = f"{item.get('action') or ''} {item.get('mode') or ''}".lower()
        if any(marker in action for marker in removal_markers):
            continue
        context = contexts.setdefault(
            int(item["key_id"]),
            {"is_used": True, "assignments": [], "panels": [], "panel_ids": []},
        )
        # A recorded physical-panel relation also means the key is already in
        # use, including legacy/imported rows without an active assignment.
        context["is_used"] = True
        panel = {
            "id": int(item["panel_id"]),
            "address": item.get("address") or "",
            "entrance": item.get("entrance") or "",
            "name": item.get("name") or "",
            "mac": item.get("mac") or "",
        }
        context["panels"].append(panel)
        context["panel_ids"].append(panel["id"])
    return contexts


def get_key_history(key_id: int, limit: int = 200) -> list[dict]:
    key = get_key(key_id)
    if not key:
        return []

    with db() as conn:
        rows = conn.execute(
            """
            SELECT *
            FROM operation_log
            WHERE key_id = ?
               OR (
                    key_id IS NULL
                    AND printed_number = ?
                    AND UPPER(hex_value) = UPPER(?)
               )
            ORDER BY id DESC
            LIMIT ?
            """,
            (key_id, key["number"], key["hex_value"], limit),
        ).fetchall()
        return [dict(row) for row in rows]


def get_key_assignments(key_id: int) -> list[dict]:
    with db() as conn:
        rows = conn.execute(
            """
            SELECT
                ka.*,
                e.full_name AS employee_name,
                ug.name AS uk_name
            FROM key_assignments ka
            LEFT JOIN employees e ON e.id = ka.employee_id
            LEFT JOIN uk_groups ug ON ug.id = ka.uk_group_id
            WHERE ka.key_id = ?
            ORDER BY ka.active DESC, ka.id DESC
            """,
            (key_id,),
        ).fetchall()
        result = []
        for row in rows:
            item = dict(row)
            item["assignment_type_name"] = ASSIGNMENT_TYPE_NAMES.get(
                item.get("assignment_type"),
                item.get("assignment_type") or "—",
            )
            item["owner_name"] = (
                item.get("note")
                or item.get("employee_name")
                or item.get("uk_name")
                or ""
            )
            result.append(item)
        return result


def get_assignment_addresses() -> list[str]:
    """Return canonical address choices already present in the panel registry."""
    with db() as conn:
        return [
            row[0]
            for row in conn.execute(
                """
                SELECT MIN(address) AS address
                FROM panels
                WHERE BTRIM(COALESCE(address, '')) <> ''
                GROUP BY SMART_NORM(address)
                ORDER BY SMART_NORM(MIN(address))
                """
            )
        ]


def _assignment_description(row: dict) -> str:
    assignment_type = row.get("assignment_type") or ""
    parts = [ASSIGNMENT_TYPE_NAMES.get(assignment_type, assignment_type or "—")]
    address = (row.get("address") or "").strip()
    apartment = (row.get("apartment") or "").strip()
    owner_name = (
        row.get("owner_name")
        or row.get("note")
        or row.get("employee_name")
        or row.get("uk_name")
        or ""
    ).strip()
    if address:
        parts.append(address)
    parts.append(f"квартира {apartment}" if apartment else "квартира не указана")
    if owner_name:
        parts.append(owner_name)
    return ", ".join(parts)


def update_key_assignment(
    key_id: int,
    assignment_type: str,
    *,
    address: str,
    apartment: str = "",
    owner_name: str = "",
    reason: str,
    assigned_by: str = "",
) -> dict:
    """Replace only the CRM assignment and preserve the previous row as history."""
    if assignment_type not in ASSIGNMENT_STATUSES:
        raise ValueError("Некорректный тип владельца ключа.")
    clean_reason = (reason or "").strip()
    if not clean_reason:
        raise ValueError("Укажите причину изменения назначения.")
    clean_address = (address or "").strip()
    if not clean_address:
        raise ValueError("Выберите адрес из реестра CRM.")

    with db() as conn:
        key_row = conn.execute(
            "SELECT id FROM keys WHERE id = ? FOR UPDATE",
            (key_id,),
        ).fetchone()
        if not key_row:
            raise ValueError("Ключ не найден.")
        current_row = conn.execute(
            """
            SELECT ka.*, e.full_name AS employee_name, ug.name AS uk_name
            FROM key_assignments ka
            LEFT JOIN employees e ON e.id = ka.employee_id
            LEFT JOIN uk_groups ug ON ug.id = ka.uk_group_id
            WHERE ka.key_id = ? AND ka.active = 1
            LIMIT 1
            """,
            (key_id,),
        ).fetchone()
        if not current_row:
            raise ValueError("У ключа нет текущего назначения для редактирования.")

        stored_address = conn.execute(
            """
            SELECT MIN(address)
            FROM panels
            WHERE SMART_NORM(address) = SMART_NORM(?)
              AND BTRIM(COALESCE(address, '')) <> ''
            """,
            (clean_address,),
        ).fetchone()[0]
        if not stored_address:
            raise ValueError("Адрес не найден в CRM. Выберите существующий адрес.")

        current = dict(current_row)
        current["owner_name"] = (
            current.get("note")
            or current.get("employee_name")
            or current.get("uk_name")
            or ""
        )
        old_description = _assignment_description(current)

        employee_id = (
            current.get("employee_id")
            if assignment_type == "employee"
            and current.get("assignment_type") == "employee"
            else None
        )
        uk_group_id = (
            current.get("uk_group_id")
            if assignment_type == "uk" and current.get("assignment_type") == "uk"
            else None
        )

        conn.execute(
            """
            UPDATE key_assignments
            SET active = 0, released_at = CURRENT_TIMESTAMP
            WHERE id = ?
            """,
            (current["id"],),
        )
        set_key_assignment_on_connection(
            conn,
            key_id,
            assignment_type,
            address=stored_address,
            apartment=(apartment or "").strip(),
            employee_id=employee_id,
            uk_group_id=uk_group_id,
            assigned_by=(assigned_by or "").strip(),
            note=(owner_name or "").strip(),
        )

        new_row = conn.execute(
            """
            SELECT ka.*, e.full_name AS employee_name, ug.name AS uk_name
            FROM key_assignments ka
            LEFT JOIN employees e ON e.id = ka.employee_id
            LEFT JOIN uk_groups ug ON ug.id = ka.uk_group_id
            WHERE ka.key_id = ? AND ka.active = 1
            LIMIT 1
            """,
            (key_id,),
        ).fetchone()
        updated = dict(new_row)
        updated["owner_name"] = (
            updated.get("note")
            or updated.get("employee_name")
            or updated.get("uk_name")
            or ""
        )
        new_description = _assignment_description(updated)
        return {
            "old": current,
            "new": updated,
            "old_description": old_description,
            "new_description": new_description,
            "reason": clean_reason,
        }


def prepare_key_range(
    key_type_id: int,
    start_number: int | str,
    count: int,
    created_by: str,
) -> dict:
    start_text = str(start_number).strip()
    if not re.fullmatch(r"[0-9]+", start_text):
        raise ValueError("Начальный номер должен состоять только из цифр.")
    if count < 1 or count > 1000:
        raise ValueError("За один раз можно подготовить от 1 до 1000 ключей.")

    start_value = int(start_text)
    number_width = len(start_text)
    numbers = [
        str(number).zfill(number_width)
        for number in range(start_value, start_value + count)
    ]

    key_type = get_key_type(key_type_id)
    if not key_type or not key_type.get("enabled"):
        raise ValueError("Выберите активный тип ключа.")

    number_placeholders = ",".join("?" for _ in numbers)
    with db() as conn:
        rows = conn.execute(
            f"""
            SELECT k.*, kt.name AS type_name, kt.color AS type_color
            FROM keys k
            JOIN key_types kt ON kt.id = k.key_type_id
            WHERE k.key_type_id = ?
              AND k.number IN ({number_placeholders})
            ORDER BY LENGTH(k.number), k.number
            """,
            (key_type_id, *numbers),
        ).fetchall()

    existing_by_number = {
        str(row["number"]): dict(row)
        for row in rows
    }
    filled_rows = [
        row
        for row in existing_by_number.values()
        if (row.get("hex_value") or "").strip()
    ]
    pending_rows = []
    legacy_placeholders = 0
    for number in numbers:
        existing_row = existing_by_number.get(number)
        if existing_row and (existing_row.get("hex_value") or "").strip():
            continue
        if existing_row:
            legacy_placeholders += 1
        pending_rows.append(
            {
                "number": number,
                "key_type_id": key_type_id,
                "type_name": key_type["name"],
                "type_color": key_type["color"],
            }
        )

    return {
        "created": 0,
        "existing": len(existing_by_number),
        "requested": count,
        "resumed": legacy_placeholders,
        "filled_existing": len(filled_rows),
        "filled_rows": filled_rows,
        "rows": pending_rows,
        "key_type": key_type,
        "start": numbers[0],
        "end": numbers[-1],
        "count": count,
    }


def save_prepared_key(
    key_type_id: int,
    number: str,
    hex_value: str,
    username: str = "",
    allow_replace: bool = False,
) -> dict:
    clean_number = (number or "").strip()
    clean_hex = _normalize_hex(hex_value)

    if not re.fullmatch(r"[0-9]+", clean_number):
        raise ValueError("Номер подготовленного ключа должен состоять только из цифр.")
    if not re.fullmatch(r"[0-9A-F]{6,16}", clean_hex):
        raise ValueError("HEX должен содержать от 6 до 16 символов 0-9/A-F.")

    key_type = get_key_type(key_type_id)
    if not key_type or not key_type.get("enabled"):
        raise ValueError("Выберите активный тип ключа.")

    with db() as conn:
        existing = conn.execute(
            """
            SELECT id, hex_value
            FROM keys
            WHERE key_type_id = ? AND LOWER(number) = LOWER(?)
            LIMIT 1
            """,
            (key_type_id, clean_number),
        ).fetchone()
        existing_id = int(existing["id"]) if existing else None
        current_hex = _normalize_hex(existing["hex_value"] or "") if existing else ""

        if current_hex and current_hex != clean_hex and not allow_replace:
            raise ValueError(
                "У этого номера уже сохранён HEX. Нажмите «Исправить», чтобы заменить его осознанно."
            )

        duplicate_sql = """
            SELECT k.id, k.number, kt.name AS type_name
            FROM keys k
            JOIN key_types kt ON kt.id = k.key_type_id
            WHERE UPPER(k.hex_value) = ?
        """
        duplicate_params: list = [clean_hex]
        if existing_id is not None:
            duplicate_sql += " AND k.id <> ?"
            duplicate_params.append(existing_id)
        duplicate_sql += " LIMIT 1"
        duplicate = conn.execute(
            duplicate_sql,
            duplicate_params,
        ).fetchone()
        if duplicate:
            raise ValueError(
                f"HEX уже принадлежит ключу {duplicate['type_name']} №{duplicate['number']}."
            )

        if existing:
            try:
                conn.execute(
                    """
                    UPDATE keys
                    SET hex_value = ?,
                        key_type = ?,
                        updated_at = CURRENT_TIMESTAMP,
                        created_by = CASE WHEN created_by = '' THEN ? ELSE created_by END
                    WHERE id = ?
                    """,
                    (clean_hex, key_type["name"], username, existing_id),
                )
            except IntegrityError as error:
                raise ValueError(
                    "Номер или HEX уже был сохранён другим оператором. Обновите данные."
                ) from error
            key_id = existing_id
        else:
            try:
                cursor = conn.execute(
                    """
                    INSERT INTO keys(
                        key_type_id,
                        number,
                        hex_value,
                        key_type,
                        status,
                        created_by
                    )
                    VALUES (?, ?, ?, ?, 'free', ?)
                    """,
                    (
                        key_type_id,
                        clean_number,
                        clean_hex,
                        key_type["name"],
                        username,
                    ),
                )
            except IntegrityError as error:
                raise ValueError(
                    "Номер или HEX уже был сохранён другим оператором. Обновите партию и повторите проверку."
                ) from error
            key_id = int(cursor.lastrowid)

    key = get_key(key_id)
    if not key:
        raise ValueError("Ключ не найден после сохранения.")
    return key


def save_key_hex(
    key_id: int,
    hex_value: str,
    username: str = "",
    allow_replace: bool = False,
) -> dict:
    clean_hex = _normalize_hex(hex_value)

    if not re.fullmatch(r"[0-9A-F]{6,16}", clean_hex):
        raise ValueError("HEX должен содержать от 6 до 16 символов 0-9/A-F.")

    with db() as conn:
        current = conn.execute(
            "SELECT id, hex_value FROM keys WHERE id = ? FOR UPDATE",
            (key_id,),
        ).fetchone()
        if not current:
            raise ValueError("Ключ не найден.")

        current_hex = _normalize_hex(current["hex_value"] or "")
        if current_hex and current_hex != clean_hex and not allow_replace:
            raise ValueError(
                "HEX уже сохранён. Нажмите «Исправить», чтобы заменить его осознанно."
            )

        duplicate = conn.execute(
            """
            SELECT k.id, k.number, kt.name AS type_name
            FROM keys k
            JOIN key_types kt ON kt.id = k.key_type_id
            WHERE UPPER(k.hex_value) = ? AND k.id <> ?
            LIMIT 1
            """,
            (clean_hex, key_id),
        ).fetchone()
        if duplicate:
            raise ValueError(
                f"HEX уже принадлежит ключу {duplicate['type_name']} №{duplicate['number']}."
            )

        try:
            cursor = conn.execute(
                """
                UPDATE keys
                SET hex_value = ?,
                    updated_at = CURRENT_TIMESTAMP,
                    created_by = CASE WHEN created_by = '' THEN ? ELSE created_by END
                WHERE id = ?
                """,
                (clean_hex, username, key_id),
            )
        except IntegrityError as error:
            raise ValueError("Такой HEX уже сохранён у другого ключа.") from error
        if cursor.rowcount == 0:
            raise ValueError("Ключ не найден.")

    key = get_key(key_id)
    if not key:
        raise ValueError("Ключ не найден.")
    return key


def update_key(
    key_id: int,
    key_type_id: int,
    number: str,
    hex_value: str,
    note: str,
) -> None:
    clean_number = (number or "").strip()
    clean_hex = _normalize_hex(hex_value)

    if not clean_number:
        raise ValueError("Укажите номер ключа.")
    if not clean_hex:
        raise ValueError("Ключ нельзя сохранить без HEX.")
    if not re.fullmatch(r"[0-9A-F]{6,16}", clean_hex):
        raise ValueError("Некорректный HEX ключа.")
    key_type = get_key_type(key_type_id)
    if not key_type:
        raise ValueError("Тип ключа не найден.")

    with db() as conn:
        stored = conn.execute(
            "SELECT id FROM keys WHERE id = ? FOR UPDATE",
            (key_id,),
        ).fetchone()
        if not stored:
            raise ValueError("Ключ не найден.")
        duplicate = conn.execute(
            "SELECT id FROM keys WHERE UPPER(hex_value) = ? AND id <> ? LIMIT 1",
            (clean_hex, key_id),
        ).fetchone()
        if duplicate:
            raise ValueError("Такой HEX уже используется другим ключом.")

        try:
            cursor = conn.execute(
                """
                UPDATE keys
                SET key_type_id = ?,
                    key_type = ?,
                    number = ?,
                    hex_value = ?,
                    note = ?,
                    updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
                """,
                (
                    key_type_id,
                    key_type["name"],
                    clean_number,
                    clean_hex,
                    (note or "").strip(),
                    key_id,
                ),
            )
        except IntegrityError as error:
            raise ValueError("Ключ с таким номером или HEX уже существует.") from error

        if cursor.rowcount == 0:
            raise ValueError("Ключ не найден.")


def set_key_assignment_on_connection(
    conn,
    key_id: int,
    assignment_type: str,
    *,
    address: str = "",
    apartment: str = "",
    employee_id: int | None = None,
    uk_group_id: int | None = None,
    assigned_by: str = "",
    note: str = "",
) -> None:
    if assignment_type not in ASSIGNMENT_STATUSES:
        raise ValueError("Некорректный тип назначения ключа.")

    stored_key = conn.execute(
        "SELECT hex_value FROM keys WHERE id = ? FOR UPDATE",
        (key_id,),
    ).fetchone()
    if not stored_key:
        raise ValueError("Ключ не найден.")
    if not (stored_key["hex_value"] or "").strip():
        raise ValueError("Ключ без HEX нельзя назначить.")

    # Синхронизируем раздел сотрудников с единым текущим назначением.
    # Выдачи УК хранятся отдельно в uk_key_issues, а здесь остаётся общая
    # проекция назначения для реестра и истории ключа.
    if assignment_type != "employee":
        conn.execute(
            """
            UPDATE employee_keys
            SET status = 'replaced',
                closed_at = CURRENT_TIMESTAMP,
                close_reason = 'Ключ переназначен',
                updated_at = CURRENT_TIMESTAMP
            WHERE key_id = ? AND status = 'active'
            """,
            (key_id,),
        )

    current = conn.execute(
        """
        SELECT *
        FROM key_assignments
        WHERE key_id = ? AND active = 1
        LIMIT 1
        """,
        (key_id,),
    ).fetchone()

    same_assignment = bool(
        current
        and current["assignment_type"] == assignment_type
        and (
            assignment_type == "employee"
            and current["employee_id"] == employee_id
            or assignment_type == "uk"
            and current["uk_group_id"] == uk_group_id
            or assignment_type == "resident"
            and (current["address"] or "").strip().lower() == (address or "").strip().lower()
            and (current["apartment"] or "").strip().lower() == (apartment or "").strip().lower()
        )
    )

    if same_assignment:
        conn.execute(
            """
            UPDATE key_assignments
            SET address = CASE WHEN ? <> '' THEN ? ELSE address END,
                apartment = CASE WHEN ? <> '' THEN ? ELSE apartment END,
                assigned_by = CASE WHEN ? <> '' THEN ? ELSE assigned_by END,
                note = CASE WHEN ? <> '' THEN ? ELSE note END
            WHERE id = ?
            """,
            (
                (address or "").strip(),
                (address or "").strip(),
                (apartment or "").strip(),
                (apartment or "").strip(),
                assigned_by,
                assigned_by,
                (note or "").strip(),
                (note or "").strip(),
                current["id"],
            ),
        )
        conn.execute(
            """
            UPDATE keys
            SET status = ?, is_used = 1, updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
            """,
            (ASSIGNMENT_STATUSES[assignment_type], key_id),
        )
        return

    conn.execute(
        """
        UPDATE key_assignments
        SET active = 0,
            released_at = CURRENT_TIMESTAMP
        WHERE key_id = ? AND active = 1
        """,
        (key_id,),
    )
    conn.execute(
        """
        INSERT INTO key_assignments(
            key_id,
            assignment_type,
            address,
            apartment,
            employee_id,
            uk_group_id,
            assigned_by,
            active,
            note
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?)
        """,
        (
            key_id,
            assignment_type,
            (address or "").strip(),
            (apartment or "").strip(),
            employee_id,
            uk_group_id,
            assigned_by,
            (note or "").strip(),
        ),
    )
    conn.execute(
        """
        UPDATE keys
        SET status = ?, is_used = 1, updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
        """,
        (ASSIGNMENT_STATUSES[assignment_type], key_id),
    )


def set_key_assignment(
    key_id: int,
    assignment_type: str,
    *,
    address: str = "",
    apartment: str = "",
    employee_id: int | None = None,
    uk_group_id: int | None = None,
    assigned_by: str = "",
    note: str = "",
) -> None:
    with db() as conn:
        set_key_assignment_on_connection(
            conn,
            key_id,
            assignment_type,
            address=address,
            apartment=apartment,
            employee_id=employee_id,
            uk_group_id=uk_group_id,
            assigned_by=assigned_by,
            note=note,
        )


def release_key_on_connection(conn, key_id: int, note: str = "") -> None:
    stored_key = conn.execute(
        "SELECT id FROM keys WHERE id = ? FOR UPDATE",
        (key_id,),
    ).fetchone()
    if not stored_key:
        raise ValueError("Ключ не найден.")
    conn.execute(
        """
        UPDATE employee_keys
        SET status = 'inactive',
            closed_at = CURRENT_TIMESTAMP,
            close_reason = CASE WHEN ? <> '' THEN ? ELSE 'Ключ освобождён' END,
            updated_at = CURRENT_TIMESTAMP
        WHERE key_id = ? AND status = 'active'
        """,
        ((note or "").strip(), (note or "").strip(), key_id),
    )
    conn.execute(
        """
        UPDATE key_assignments
        SET active = 0,
            released_at = CURRENT_TIMESTAMP,
            note = CASE WHEN ? <> '' THEN ? ELSE note END
        WHERE key_id = ? AND active = 1
        """,
        ((note or "").strip(), (note or "").strip(), key_id),
    )
    cursor = conn.execute(
        """
        UPDATE keys
        SET status = 'free', is_used = 0, updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
        """,
        (key_id,),
    )
    if cursor.rowcount == 0:
        raise ValueError("Ключ не найден.")


def release_key(key_id: int, note: str = "") -> None:
    with db() as conn:
        release_key_on_connection(conn, key_id, note)


def set_key_status(key_id: int, status: str, note: str = "") -> None:
    if status not in KEY_STATUSES:
        raise ValueError("Некорректный статус ключа.")

    if status == "free":
        release_key(key_id, note)
        return

    with db() as conn:
        if status in {"blocked", "lost", "defective", "archived"}:
            release_key_on_connection(conn, key_id, note)
        cursor = conn.execute(
            """
            UPDATE keys
            SET status = ?,
                is_used = CASE WHEN ? = 'free' THEN 0 ELSE is_used END,
                note = CASE WHEN ? <> '' THEN ? ELSE note END,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
            """,
            (status, status, (note or "").strip(), (note or "").strip(), key_id),
        )
        if cursor.rowcount == 0:
            raise ValueError("Ключ не найден.")


def get_all_keys_for_export() -> list[dict]:
    with db() as conn:
        rows = conn.execute(
            """
            SELECT
                k.id,
                kt.name AS type_name,
                k.number,
                k.hex_value,
                k.status,
                k.note,
                k.created_at,
                k.updated_at,
                k.created_by
            FROM keys k
            JOIN key_types kt ON kt.id = k.key_type_id
            WHERE TRIM(k.hex_value) <> ''
            ORDER BY LOWER(kt.name), kt.name, LENGTH(k.number), k.number
            """
        ).fetchall()
        return [dict(row) for row in rows]
